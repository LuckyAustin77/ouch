document.addEventListener('DOMContentLoaded', () => {
    // Mobile Menu Toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            hamburger.innerHTML = navLinks.classList.contains('active') ? '✕' : '☰';
        });
    }

    // Service Page Logic
    const params = new URLSearchParams(window.location.search);
    const serviceKey = params.get('service');
    const serviceContentContainer = document.getElementById('service-content-container');
    const serviceTitle = document.getElementById('service-title');

    if (serviceKey && servicesData[serviceKey]) {
        // We are on the service detail page and have a valid key
        const data = servicesData[serviceKey];
        if (serviceTitle) serviceTitle.textContent = data.title;
        if (serviceContentContainer) {
            serviceContentContainer.innerHTML = data.content;
        }
        document.title = `${data.title} - Baba Vasant K Khande`;
    } else if (window.location.pathname.includes('service.html')) {
        // On service page but no key or invalid key, redirect or show error
        if (serviceContentContainer) {
            serviceContentContainer.innerHTML = '<p>Service not found. Please go back to the <a href="index.html">Home Page</a>.</p>';
        }
    }

    // Dynamic Service List for Index Page (Optional, if we want to generate the grid dynamically)
    const servicesGrid = document.querySelector('.services-grid-dynamic');
    if (servicesGrid) {
        Object.keys(servicesData).forEach(key => {
            const service = servicesData[key];
            const card = document.createElement('div');
            card.className = 'service-card';
            card.onclick = () => window.location.href = `service.html?service=${key}`;

            // Simple icon mapping or default
            let icon = '🔮';
            if (key.includes('palm')) icon = '✋';
            if (key.includes('love')) icon = '❤️';
            if (key.includes('money') || key.includes('finance')) icon = '💰';
            if (key.includes('home') || key.includes('vastu')) icon = '🏠';

            card.innerHTML = `
                <div class="service-icon">${icon}</div>
                <h3>${service.title}</h3>
                <p>${service.description}</p>
                <span class="read-more">Read More &rarr;</span>
            `;
            servicesGrid.appendChild(card);
        });
    }
});
