const servicesData = {
    "palmistry": {
        title: "Palmistry (Palm Reading)",
        description: "Unlock the secrets of your destiny through the ancient art of Palmistry. Baba Vasant K Khande examines the lines, mounts, and shapes of your hands to reveal your past, present, and future.",
        content: `
            <p>Palmistry, or Chiromancy, is one of the oldest and most revered occult sciences in the world. It is the art of analyzing the physical features of the hands to interpret personality characteristics and predict future happenings. Baba Vasant K Khande is a renowned expert in this field, with decades of experience in deciphering the intricate language of the palms.</p>
            
            <h3>Why Choose Palmistry?</h3>
            <p>Your hands are a map of your life. Every line, from the Life Line to the Heart Line, tells a story. Baba Vasant K Khande's detailed reading can help you understand:</p>
            <ul>
                <li><strong>Life Path & Longevity:</strong> Understanding the vitality and major events in your life journey.</li>
                <li><strong>Love & Relationships:</strong> Insights into your romantic life, marriage prospects, and emotional stability.</li>
                <li><strong>Career & Success:</strong> Identifying your natural talents, career obstacles, and periods of financial prosperity.</li>
                <li><strong>Health & Well-being:</strong> Early indications of health issues and energy levels.</li>
            </ul>

            <h3>Our Approach</h3>
            <p>Baba Vasant K Khande does not just look at the lines; he examines the shape of the hand, the texture of the skin, the flexibility of the fingers, and the mounts of the planets. This holistic approach ensures a comprehensive reading that goes beyond surface-level predictions. Whether you are facing uncertainty in your career or turmoil in your relationships, a palm reading session can provide the clarity and direction you seek.</p>
            
            <p>The session is conducted in a calm, spiritual environment where you can feel at ease. Baba Ji explains every observation in detail, ensuring you leave with a clear understanding of your potential and the remedies needed to overcome any negative indications.</p>
        `
    },
    "pooja": {
        title: "All Sorts of Pooja",
        description: "Perform sacred rituals and poojas to appease the deities and bring prosperity, peace, and success into your life. Baba Vasant K Khande conducts authentic Vedic poojas.",
        content: `
            <p>In the Vedic tradition, Pooja is a powerful way to connect with the Divine. It is a ceremonial act of worship that invokes positive energies and dispels negativity. Baba Vasant K Khande specializes in conducting a wide variety of Poojas tailored to specific needs and planetary doshas.</p>

            <h3>Types of Poojas We Offer</h3>
            <ul>
                <li><strong>Satyanarayan Pooja:</strong> For general well-being, prosperity, and truth.</li>
                <li><strong>Ganesh Pooja:</strong> To remove obstacles before starting any new venture.</li>
                <li><strong>Lakshmi Pooja:</strong> For wealth, financial stability, and abundance.</li>
                <li><strong>Navagraha Shanti Pooja:</strong> To appease the nine planets and reduce their malefic effects.</li>
                <li><strong>Rudra Abhishek:</strong> A powerful pooja for Lord Shiva to gain health and protection.</li>
                <li><strong>Vastu Shanti Pooja:</strong> To cleanse a home or office of negative Vastu doshas.</li>
            </ul>

            <h3>The Importance of Authentic Rituals</h3>
            <p>A Pooja is only effective when performed with the right mantras, vidhi (procedure), and shradha (faith). Baba Vasant K Khande is well-versed in the ancient scriptures and ensures that every ritual is performed with strict adherence to Vedic traditions. He uses high-quality Samagri (ritual materials) and chants mantras with precise pronunciation to generate the maximum spiritual vibration.</p>

            <p>Whether you are facing a crisis, starting a new chapter in life, or simply wish to express gratitude to the Almighty, Baba Ji will guide you on the most appropriate Pooja to perform. These rituals can bring profound peace to your mind and harmony to your family.</p>
        `
    },
    "astrology": {
        title: "Astrology Consultation",
        description: "Comprehensive astrological readings based on your birth chart. Understand the planetary influences on your life and get remedies for a better future.",
        content: `
            <p>Astrology is the study of the movements and relative positions of celestial bodies interpreted as having an influence on human affairs and the natural world. Baba Vasant K Khande is a master astrologer who combines the wisdom of Vedic Astrology (Jyotish Shastra) with modern insights to provide accurate and life-changing predictions.</p>

            <h3>What We Analyze</h3>
            <p>Using your date, time, and place of birth, Baba Ji constructs your Janam Kundli (Birth Chart). This chart is a snapshot of the cosmos at the moment you were born. The analysis covers:</p>
            <ul>
                <li><strong>Planetary Positions:</strong> How the sun, moon, and planets influence your personality and destiny.</li>
                <li><strong>Dashas and Transits:</strong> Predicting future events based on planetary periods.</li>
                <li><strong>Doshas:</strong> Identifying negative combinations like Mangal Dosha, Kaal Sarp Dosha, or Shani Sade Sati.</li>
                <li><strong>Yogas:</strong> Highlighting auspicious combinations that promise success and fame.</li>
            </ul>

            <h3>Guidance for All Aspects of Life</h3>
            <p>Astrology is not just about prediction; it is about preparation. Baba Vasant K Khande provides guidance on:</p>
            <ul>
                <li><strong>Career & Business:</strong> Choosing the right field and timing for investments.</li>
                <li><strong>Marriage & Relationships:</strong> Finding the right partner and resolving conflicts.</li>
                <li><strong>Health:</strong> Precautionary measures for potential health issues.</li>
            </ul>

            <p>With Baba Ji's guidance, you can navigate the ups and downs of life with confidence. He provides simple yet effective remedies such as gemstone recommendations, mantra chanting, and charity to mitigate negative effects and enhance positive ones.</p>
        `
    },
    "flat-land": {
        title: "Flat and Land Examination",
        description: "Expert analysis of properties before you buy or build. Ensure your new home or office brings luck and prosperity.",
        content: `
            <p>Buying a property is one of the biggest investments in a person's life. However, not every piece of land or flat is lucky for everyone. The energy of the land (Bhoomi) can significantly impact the occupants' health, wealth, and happiness. Baba Vasant K Khande offers specialized Flat and Land Examination services to ensure your investment is auspicious.</p>

            <h3>What We Check</h3>
            <ul>
                <li><strong>Direction & Orientation:</strong> Ensuring the entrance and layout align with positive magnetic fields.</li>
                <li><strong>Soil Quality:</strong> Analyzing the energy of the soil (Bhoomi Parikshan).</li>
                <li><strong>Surroundings:</strong> Checking for negative influences like nearby graveyards, hospitals, or T-junctions.</li>
                <li><strong>Shape of the Plot:</strong> Avoiding irregular shapes that can cause instability.</li>
                <li><strong>History of the Land:</strong> Ensuring the land does not have a history of bad luck or tragedy.</li>
            </ul>

            <h3>Vastu Compliance</h3>
            <p>Baba Vasant K Khande integrates Vastu Shastra principles with his intuitive powers to sense the vibrations of a place. He will visit the site (or analyze detailed floor plans) to identify any Vastu Doshas. If a property has minor defects, he suggests practical remedies without the need for major demolition.</p>

            <p>Before you sign the deal, consult Baba Ji to ensure that your new home or office will be a sanctuary of peace and prosperity, not a source of stress.</p>
        `
    },
    "match-making": {
        title: "Match Making (Kundli Milan)",
        description: "Find your perfect soulmate with Vedic Match Making. We analyze compatibility on 36 Gunas to ensure a happy and long-lasting marriage.",
        content: `
            <p>Marriage is a sacred union of two souls. In Indian culture, Kundli Milan (Horoscope Matching) is a crucial step before finalizing a marriage. It ensures that the couple is compatible not just emotionally, but also spiritually and astrologically. Baba Vasant K Khande is an expert in Gun Milan and detailed compatibility analysis.</p>

            <h3>The Process of Gun Milan</h3>
            <p>Baba Ji analyzes the horoscopes of the bride and groom based on the Ashtakoot Milan system, which checks compatibility across eight categories (Kootas), totaling 36 Gunas. These include:</p>
            <ul>
                <li><strong>Varna (Ego):</strong> Spiritual compatibility.</li>
                <li><strong>Vashya (Attraction):</strong> Mutual control and attraction.</li>
                <li><strong>Tara (Destiny):</strong> Birth star compatibility.</li>
                <li><strong>Yoni (Intimacy):</strong> Sexual compatibility.</li>
                <li><strong>Graha Maitri (Friendship):</strong> Psychological compatibility.</li>
                <li><strong>Gana (Temperament):</strong> Nature and behavior.</li>
                <li><strong>Bhakoot (Love):</strong> Emotional connection.</li>
                <li><strong>Nadi (Health):</strong> Genetic and health compatibility.</li>
            </ul>

            <h3>Beyond the Gunas</h3>
            <p>While a high Guna score is good, it is not the only factor. Baba Vasant K Khande goes deeper to check for Mangal Dosha, longevity of the partners, and future financial stability of the couple. He provides an honest and detailed report, helping families make an informed decision.</p>

            <p>Let Baba Ji help you lay the foundation for a blissful and harmonious married life.</p>
        `
    },
    "love-problem": {
        title: "Love Problem Solution",
        description: "Facing issues in your love life? Get powerful remedies to resolve conflicts, bring back a lost lover, or convince parents for marriage.",
        content: `
            <p>Love is the most beautiful feeling, but it can also bring immense pain when things go wrong. Whether it's misunderstandings, lack of trust, third-party interference, or parental opposition, love problems can be overwhelming. Baba Vasant K Khande is a compassionate guide who has helped countless couples reunite and find happiness.</p>

            <h3>Common Love Problems We Solve</h3>
            <ul>
                <li><strong>One-Sided Love:</strong> Attracting the person you desire.</li>
                <li><strong>Breakups:</strong> Healing a broken heart and getting your ex back.</li>
                <li><strong>Cheating Partners:</strong> Restoring trust and fidelity in the relationship.</li>
                <li><strong>Constant Fights:</strong> Removing negative energies causing discord.</li>
                <li><strong>Inter-religion/Inter-caste Issues:</strong> Overcoming societal and family barriers.</li>
            </ul>

            <h3>Astrological Remedies for Love</h3>
            <p>Baba Ji analyzes the 5th and 7th houses of your horoscope, which govern love and marriage. He identifies the planetary afflictions causing the turmoil (often Venus, Mars, or Rahu). Based on this, he suggests powerful Vashikaran mantras, gemstones, and rituals to:</p>
            <ul>
                <li>Enhance attraction and understanding.</li>
                <li>Remove obstacles and rivals.</li>
                <li>Create a harmonious bond between partners.</li>
            </ul>

            <p>Don't let your love story end in tears. Consult Baba Vasant K Khande for a solution that works.</p>
        `
    },
    "career-problem": {
        title: "Career & Job Problems",
        description: "Stuck in your career? Facing office politics or unemployment? Get astrological guidance to boost your professional growth.",
        content: `
            <p>In today's competitive world, career stress is common. Despite hard work, many people face stagnation, job loss, or lack of recognition. Baba Vasant K Khande offers specialized astrological consultations to diagnose the root cause of your professional hurdles and provide effective remedies.</p>

            <h3>Issues We Address</h3>
            <ul>
                <li><strong>Job Instability:</strong> Frequent job changes or fear of layoffs.</li>
                <li><strong>Lack of Promotion:</strong> Being overlooked despite good performance.</li>
                <li><strong>Office Politics:</strong> Harassment or negativity from colleagues/bosses.</li>
                <li><strong>Wrong Career Path:</strong> Feeling unfulfilled in your current field.</li>
                <li><strong>Unemployment:</strong> Difficulty finding a job after a break or education.</li>
            </ul>

            <h3>Astrological Solutions</h3>
            <p>Baba Ji examines the 10th House (House of Karma/Career) and the position of Saturn (Lord of Karma) and Jupiter (Lord of Wealth/Wisdom). He provides solutions such as:</p>
            <ul>
                <li><strong>Gemstone Therapy:</strong> Wearing Blue Sapphire or Emerald to boost career luck (only after consultation).</li>
                <li><strong>Mantras:</strong> Powerful chants to remove obstacles.</li>
                <li><strong>Yantras:</strong> Energized instruments to keep at your workspace for positive energy.</li>
            </ul>

            <p>Unlock your true potential and achieve the success you deserve with Baba Ji's guidance.</p>
        `
    },
    "education-job": {
        title: "Education & Job",
        description: "Guidance for students and job seekers. Choose the right stream of study and find the job that suits your destiny.",
        content: `
            <p>Education is the foundation of a successful life. Parents often worry about their children's focus, exam results, and future career paths. Similarly, fresh graduates struggle to find the right job. Baba Vasant K Khande helps bridge the gap between effort and success through astrology.</p>

            <h3>For Students</h3>
            <ul>
                <li><strong>Concentration Issues:</strong> Remedies to improve memory and focus.</li>
                <li><strong>Stream Selection:</strong> Astrological advice on whether to choose Science, Commerce, or Arts based on planetary strengths (Mercury for intellect, Jupiter for wisdom).</li>
                <li><strong>Exam Anxiety:</strong> Rituals to calm the mind and ensure peak performance.</li>
                <li><strong>Foreign Education:</strong> Predicting chances of studying abroad.</li>
            </ul>

            <h3>For Job Seekers</h3>
            <p>Baba Ji helps identify the most auspicious periods for applying for jobs and attending interviews. He can also guide you on which industries will bring you the most success and satisfaction.</p>

            <p>Empower your educational and professional journey with divine wisdom.</p>
        `
    },
    "family-problem": {
        title: "Family Problem Solution",
        description: "Restore peace and harmony in your family. Resolve disputes between siblings, parents, or in-laws with spiritual remedies.",
        content: `
            <p>A happy family is a source of strength, but conflicts can turn a home into a war zone. Property disputes, misunderstandings between generations, or interference from in-laws can destroy domestic peace. Baba Vasant K Khande specializes in resolving complex family dynamics.</p>

            <h3>Common Family Issues</h3>
            <ul>
                <li><strong>Property Disputes:</strong> Legal and personal battles over inheritance.</li>
                <li><strong>Sibling Rivalry:</strong> Jealousy and conflict between brothers and sisters.</li>
                <li><strong>Parent-Child Conflicts:</strong> Generation gap and lack of respect.</li>
                <li><strong>Joint Family Issues:</strong> Adjustment problems in large families.</li>
            </ul>

            <h3>Restoring Harmony</h3>
            <p>Baba Ji analyzes the 2nd House (Family) and 4th House (Domestic Happiness) of the key family members. He identifies the negative energies or 'Griha Klesh' affecting the home. Remedies may include:</p>
            <ul>
                <li><strong>Havan/Yagya:</strong> To purify the home environment.</li>
                <li><strong>Vastu Corrections:</strong> Small changes in the home layout to improve energy flow.</li>
                <li><strong>Counseling:</strong> Spiritual counseling to foster forgiveness and understanding.</li>
            </ul>

            <p>Bring laughter and love back into your home with Baba Vasant K Khande's help.</p>
        `
    },
    "financial-business": {
        title: "Financial & Business Problems",
        description: "Overcome losses, debt, and business failure. attract wealth and abundance with proven astrological strategies.",
        content: `
            <p>Financial stability is essential for a secure life. Whether you are a business owner facing losses or an individual drowning in debt, astrology can offer a way out. Baba Vasant K Khande is an expert in financial astrology (Dhan Yoga).</p>

            <h3>Business Solutions</h3>
            <ul>
                <li><strong>New Ventures:</strong> Auspicious dates (Muhurat) for launching a business.</li>
                <li><strong>Partnership Issues:</strong> Checking compatibility with business partners.</li>
                <li><strong>Removing Blockages:</strong> Why deals are getting stuck or clients are leaving.</li>
                <li><strong>Expansion:</strong> When and where to expand your business.</li>
            </ul>

            <h3>Financial Remedies</h3>
            <p>Baba Ji analyzes the 2nd House (Wealth) and 11th House (Gains). He suggests remedies to appease Goddess Lakshmi and Lord Kuber. These may include:</p>
            <ul>
                <li><strong>Shree Yantra:</strong> Installation of a powerful yantra for wealth attraction.</li>
                <li><strong>Donations:</strong> Specific charities to balance karmic debts.</li>
                <li><strong>Gemstones:</strong> Yellow Sapphire or Diamond to attract luxury and money.</li>
            </ul>

            <p>Turn your financial situation around and build lasting wealth with Baba Ji's expert advice.</p>
        `
    },
    "future-predictions": {
        title: "Future Predictions",
        description: "Get a detailed roadmap of your future. Know what lies ahead in the next 1, 5, or 10 years.",
        content: `
            <p>Uncertainty about the future is a major source of anxiety. "What will happen next?" is a question we all ask. Baba Vasant K Khande uses the precision of Vedic Astrology to provide detailed future predictions that help you plan your life better.</p>
            <p>Baba Ji covers all major aspects: Health, Wealth, Career, Relationships, and Spiritual Growth. He uses the Vimshottari Dasha system and planetary transits to pinpoint the timing of major life events.</p>
            <p>Knowing your future is not about fatalism; it's about empowerment. If a difficult period is predicted, Baba Ji gives you the tools to prepare and minimize the impact. If a golden period is coming, he tells you how to maximize the opportunities.</p>
        `
    },
    "health-problems": {
        title: "Health Problems",
        description: "Chronic illness? Unexplained health issues? Astrology can reveal the medical condition and provide spiritual healing.",
        content: `
            <p>Health is wealth. Sometimes, despite the best medical treatment, a cure remains elusive. This is where Medical Astrology comes in. Baba Vasant K Khande analyzes the 6th, 8th, and 12th houses to understand the root cause of ailments.</p>
            <p>He can identify predispositions to certain diseases and suggest preventive measures. While astrology is not a substitute for medical advice, it works as a powerful complementary therapy. Remedies include Rudraksha therapy, specific mantras for health (like the Mahamrityunjaya Mantra), and dietary changes based on your Ayurvedic body type (Dosha).</p>
        `
    },
    "husband-wife": {
        title: "Husband Wife Problem",
        description: "Resolve conflicts and misunderstandings in your marriage. Save your relationship from divorce and separation.",
        content: `
            <p>The bond between husband and wife is the foundation of a family. When this bond is strained, it affects everyone. Baba Vasant K Khande helps couples overcome ego clashes, lack of intimacy, communication gaps, and external interference.</p>
            <p>Using the synastry of both partners' charts, he identifies the friction points. He provides counseling and spiritual remedies to reignite the spark of love and understanding. Don't let silence or anger destroy your marriage; seek Baba Ji's help to restore harmony.</p>
        `
    },
    "love-marriage": {
        title: "Love Marriage Specialist",
        description: "Facing opposition for your love marriage? We help you convince parents and society for a happy union.",
        content: `
            <p>In many societies, love marriage is still a taboo. Couples often face immense pressure from parents and relatives to arrange a match within their community. Baba Vasant K Khande is a Love Marriage Specialist who supports true love.</p>
            <p>He analyzes the strength of the love connection and provides remedies to soften the hearts of opposing family members. His Vashikaran techniques (positive influence) can help create a favorable atmosphere for your marriage proposal to be accepted.</p>
        `
    },
    "marriage-compatibility": {
        title: "Marriage & Compatibility",
        description: "Detailed analysis of compatibility beyond just the Gunas. Ensure mental, emotional, and spiritual harmony.",
        content: `
            <p>Compatibility is more than just liking the same movies. It's about how two lives mesh together over decades. Baba Vasant K Khande offers a deep dive into relationship compatibility.</p>
            <p>He looks at the placement of the Moon (mind) and Venus (love) to see if the couple can sustain a relationship through thick and thin. This service is essential for both arranged and love marriages to ensure a conflict-free life.</p>
        `
    },
    "negative-energy": {
        title: "Negative Energy Remedies",
        description: "Feeling drained, unlucky, or anxious? You might be affected by negative energy. Get cleansed today.",
        content: `
            <p>Negative energy can come from the 'Evil Eye' (Nazar), jealousy of others, or geopathic stress. It manifests as sudden illness, loss of money, or constant lethargy. Baba Vasant K Khande is an expert in aura cleansing and energy healing.</p>
            <p>He uses ancient rituals, salt water remedies, and protective amulets (Taweez) to shield you from negativity. Once the negative energy is removed, you will feel an immediate sense of lightness and positivity.</p>
        `
    },
    "horoscope-kundli": {
        title: "Horoscope Kundli Reading",
        description: "Get your detailed birth chart made and analyzed. The blueprint of your life explained.",
        content: `
            <p>Your Kundli is your cosmic identity card. Baba Vasant K Khande creates accurate horoscopes using precise calculations. He explains the meaning of every house and planet in your chart.</p>
            <p>Whether you want a general overview of your life or an answer to a specific question, a Kundli reading is the starting point. It reveals your strengths, weaknesses, and the purpose of your life.</p>
        `
    },
    "vastu-shastra": {
        title: "Vastu Shastra Specialist",
        description: "Harmonize your living and working space with the laws of nature. Vastu corrections for health and wealth.",
        content: `
            <p>Vastu Shastra is the science of architecture. If your home is not Vastu compliant, it can block the flow of positive energy (Prana). Baba Vasant K Khande provides practical Vastu solutions.</p>
            <p>He suggests placement of furniture, colors for walls, and directions for sleeping/working. He specializes in 'Vastu without Demolition', using mirrors, crystals, and metals to correct defects.</p>
        `
    },
    "face-reading": {
        title: "Face Reading",
        description: "Your face is the mirror of your soul. Learn about your personality and future through Physiognomy.",
        content: `
            <p>Face Reading (Samudrik Shastra) allows Baba Vasant K Khande to tell a person's character and destiny just by looking at them. The shape of the forehead, eyes, nose, and chin all hold secrets.</p>
            <p>This service is particularly useful when you don't have an accurate birth time. It can reveal your temperament, luck, and potential for success.</p>
        `
    },
    "black-magic": {
        title: "Black Magic Removal",
        description: "Protect yourself and your family from dark arts and hexes. Powerful removal and protection rituals.",
        content: `
            <p>Black Magic (Kala Jadu) is a reality that can ruin lives. If you are experiencing sudden, unexplainable tragedies, it could be the work of a malevolent force. Baba Vasant K Khande is a fearless healer who can break any curse.</p>
            <p>He uses powerful Tantric rituals to cut the connection of the black magic and sends it back to its source. He also provides a 'Suraksha Kavach' (Protection Shield) to ensure it never touches you again.</p>
        `
    },
    "vashikaran": {
        title: "Vashikaran Specialist",
        description: "Influence and attract the people you want in your life. Positive Vashikaran for love and business.",
        content: `
            <p>Vashikaran is a Sanskrit word meaning 'to control'. While often misunderstood, Baba Vasant K Khande uses it for positive purposes—to save marriages, resolve enmity, and gain favor from superiors.</p>
            <p>His methods are safe and ethical, designed to bring harmony and agreement without harming anyone's free will.</p>
        `
    },
    "abroad-problem": {
        title: "Abroad Problem",
        description: "Visa rejections? Settlement issues? Get astrological help to fulfill your dream of going abroad.",
        content: `
            <p>Many people dream of settling in foreign lands but face constant hurdles. Baba Vasant K Khande analyzes the 9th and 12th houses (Foreign Travel) to see if your destiny lies overseas.</p>
            <p>He provides remedies to remove obstacles in visa processing and ensures a safe and prosperous stay abroad.</p>
        `
    },
    "divorce-problem": {
        title: "Divorce Problem",
        description: "Stop an unwanted divorce or navigate a peaceful separation. Legal and emotional guidance.",
        content: `
            <p>Divorce is painful. If you want to save your marriage, Baba Ji can help remove the negativity causing the split. If separation is inevitable, he can guide you to get a fair settlement and custody of children.</p>
            <p>He provides spiritual support to help you heal and move on with dignity.</p>
        `
    },
    "film-industry": {
        title: "Film Industry Issue",
        description: "Struggling to make it big in Bollywood or Hollywood? Astrology for actors, directors, and musicians.",
        content: `
            <p>The film industry is ruled by Venus and Rahu. Success here requires more than talent; it requires luck. Baba Vasant K Khande has guided many aspiring and established artists.</p>
            <p>He helps with name changes (Numerology), timing for auditions, and release dates for movies to ensure box office success.</p>
        `
    },
    "inter-caste": {
        title: "Inter-Caste Marriage Problem",
        description: "Bridge the gap between traditions and love. Solutions for inter-caste and inter-religion marriages.",
        content: `
            <p>Society is changing, but caste barriers still exist. Baba Vasant K Khande believes that love knows no caste. He helps couples convince orthodox families using spiritual persuasion and astrological remedies.</p>
        `
    },
    "parents-children": {
        title: "Parents and Children Problem",
        description: "Resolve generation gaps and behavioral issues. Foster love and respect in the family.",
        content: `
            <p>Children today face different pressures, leading to rebellion or withdrawal. Parents often feel helpless. Baba Ji analyzes the child's horoscope to understand their psychology.</p>
            <p>He advises parents on how to handle their children based on their astrological nature and provides remedies for the child's focus and obedience.</p>
        `
    },
    "political-problem": {
        title: "Political Problem",
        description: "Astrology for politicians. Win elections, gain power, and serve the people effectively.",
        content: `
            <p>Politics is a game of power and timing. Baba Vasant K Khande acts as a Raj Guru for many politicians. He advises on filing nominations, campaigning strategies, and oath-taking ceremonies (Muhurat).</p>
            <p>His guidance helps politicians navigate the treacherous waters of public life and achieve high office.</p>
        `
    }
};
